# Polling_System_API_Nodejs
Writing the server application in Node.js and a Database of Only the API needs to be designed.
![results](https://github.com/abhishekvikram19/Polling_System_API_Nodejs/assets/24250895/040ca7a7-166c-4a5f-8acc-67094ca8543d)
![screenshot](https://github.com/abhishekvikram19/Polling_System_API_Nodejs/assets/24250895/916e2456-7547-43d9-b5ed-fdf6bdf781d6)
